// This file is no longer needed as we're using a dialog component instead

const PrivacyPolicyPage = () => {
  return (
    <div>
      <h1>Privacy Policy</h1>
      <p>This is a placeholder for the privacy policy content.</p>
    </div>
  )
}

export default PrivacyPolicyPage
